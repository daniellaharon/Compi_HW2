import os
import subprocess

TEST_INPUTS = "./in/"
TEST_ACTUAL = "./actual/"
TEST_EXPECTED = "./expected/"

if __name__ == "__main__":
    print("Tester for compi! HW2")
    print("Current directory: ", os.getcwd())
    print("Found", len(os.listdir(TEST_INPUTS)), "tests.\n")

    print("== Compiling ==")
    command = "make"
    print(command, "\n")
    subprocess.call(command, shell=True)

    print("== Testing ==")
    for input in os.listdir(TEST_INPUTS):
        print("Running test: ", input, ": ", sep="", end="\n              ")

        input_file = TEST_INPUTS+input
        actual_file = TEST_ACTUAL+input.split(".")[0]+".out"
        expected_file = TEST_EXPECTED+input.split(".")[0]+".out"

        command = "./hw2 < "+input_file+" > "+actual_file
        print(command, end="\n              ")
        subprocess.call(command, shell=True)

        command = "diff "+expected_file+" "+actual_file
        print(command)
        subprocess.call(command, shell=True)

    print("\nEnd of tests! If no diff messages appeared above, you are good to go!")
